UM BIA25 GPA 預測器｜手機安裝版（PWA）

這是一個可加入手機主畫面的網頁 App。它會自動在同一裝置的瀏覽器儲存成績，並支援離線開啟（首次載入後）。

重要：要讓「安裝到主畫面」及離線功能正常工作，需要先把本資料夾內容放到 HTTPS 網站。直接在手機點開本地 HTML 檔可以使用部分功能，但瀏覽器通常不會提供完整 PWA 安裝能力。

最簡單的免費方式：GitHub Pages
1. 在 GitHub 建立一個新的 repository（可設為 Public）。
2. 把本資料夾內的所有檔案及 icons 資料夾上傳到 repository 根目錄。
3. 到 Settings → Pages，選擇 Deploy from a branch，Branch 選 main，資料夾選 /(root)，儲存。
4. 等待 GitHub Pages 提供 HTTPS 網址，然後用手機開啟該網址。

iPhone（Safari）
1. 用 Safari 開啟網站網址。
2. 點分享按鈕 → 加入主畫面（Add to Home Screen）→ 加入。
3. 從主畫面點擊 BIA25 GPA 圖示即可像 App 一樣開啟。

Android（Chrome）
1. 用 Chrome 開啟網站網址。
2. 點右上角 ⋮ → 安裝應用程式（Install app）或加入主畫面。
3. 安裝後從主畫面開啟。

資料保存
- 成績會自動儲存在同一裝置／同一瀏覽器的本機儲存空間。
- 清除瀏覽器網站資料、換手機或換瀏覽器，可能會清掉／無法同步資料。
- 建議定期按「匯出 CSV」備份成績。

網站部署時請上傳完整內容，不要只上傳 index.html，因為 manifest.json、sw.js 和 icons 是 PWA 安裝及離線功能所需。
